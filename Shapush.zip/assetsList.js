const outside=new Image();
outside.src = 'assets/outside.png';


const undo=new Image();
undo.src = 'assets/undo.png';

const undob=new Image();
undob.src = 'assets/undob.png';

const grab=new Image();
grab.src = 'assets/grab.png';

const grabb=new Image();
grabb.src = 'assets/grabb.png';


const restart=new Image();
restart.src = 'assets/restart.png';

const restartb=new Image();
restartb.src = 'assets/restartb.png';


const backMini=new Image();
backMini.src = 'assets/backMini.png';

const backMinib=new Image();
backMinib.src = 'assets/backMinib.png';


const stars1=new Image();
stars1.src = 'assets/stars1.png';

const stars2=new Image();
stars2.src = 'assets/stars2.png';

const stars3=new Image();
stars3.src = 'assets/stars3.png';

const stars4=new Image();
stars4.src = 'assets/stars4.png';

const stars5=new Image();
stars5.src = 'assets/stars5.png';

const current=new Image();
current.src = 'assets/current.png';


const lock=new Image();
lock.src = 'assets/lock.png';

const left=new Image();
left.src = 'assets/left.png';

const leftb=new Image();
leftb.src = 'assets/leftb.png';

const right=new Image();
right.src = 'assets/right.png';

const rightb=new Image();
rightb.src = 'assets/rightb.png';

const back=new Image();
back.src = 'assets/back.png';

const backb=new Image();
backb.src = 'assets/backb.png';

const play=new Image();
play.src = 'assets/play.png';

const playb=new Image();
playb.src = 'assets/playb.png';

const fullscreen=new Image();
fullscreen.src = 'assets/fullscreen.png';

const fullscreenb=new Image();
fullscreenb.src = 'assets/fullscreenb.png';

const exitFullscreen=new Image();
exitFullscreen.src = 'assets/exitFullscreen.png';

const exitFullscreenb=new Image();
exitFullscreenb.src = 'assets/exitFullscreenb.png';


const goal=new Image();
goal.src = 'assets/goal.png';

const title=new Image();
title.src = 'assets/title.png';

const groundTile=new Image();
groundTile.src = 'assets/ground-tile.png';

const playerImg=new Image();
playerImg.src = 'assets/3-powered-rumba.png';

const playerImgA=new Image();
playerImgA.src = 'assets/3-powered-rumba-on-a.png';

const playerImgB=new Image();
playerImgB.src = 'assets/3-powered-rumba-on-b.png';

const tile1=new Image();
tile1.src = 'assets/tile-1.png';

const tile2=new Image();
tile2.src = 'assets/tile-2.png';

const tile3=new Image();
tile3.src = 'assets/tile-3.png';

const tile4=new Image();
tile4.src = 'assets/tile-4.png';

const tile5=new Image();
tile5.src = 'assets/tile-5.png';

const tile6=new Image();
tile6.src = 'assets/tile-6.png';

const elevatorTile1=new Image();
elevatorTile1.src = 'assets/elevator-tile-1.png';

const elevatorTile2=new Image();
elevatorTile2.src = 'assets/elevator-tile-2.png';

const elevatorTile3=new Image();
elevatorTile3.src = 'assets/elevator-tile-3.png';

const elevatorTile4=new Image();
elevatorTile4.src = 'assets/elevator-tile-4.png';

const elevatorTile5=new Image();
elevatorTile5.src = 'assets/elevator-tile-5.png';

const elevatorTile6=new Image();
elevatorTile6.src = 'assets/elevator-tile-6.png';

const elevator0=new Image();
elevator0.src = 'assets/elevator-0.png';

const elevator1=new Image();
elevator1.src = 'assets/elevator-1.png';

const elevator2=new Image();
elevator2.src = 'assets/elevator-2.png';

const elevator3=new Image();
elevator3.src = 'assets/elevator-3.png';

const elevator4=new Image();
elevator4.src = 'assets/elevator-4.png';

const elevator5=new Image();
elevator5.src = 'assets/elevator-5.png';

const elevator6=new Image();
elevator6.src = 'assets/elevator-6.png';
